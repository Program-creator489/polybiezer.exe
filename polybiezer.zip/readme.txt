Malware name: polybiezer.exe
type: GDI-Trojan.Win32
Damage rate: Destructive (for non-safety version), No damage (ONLY FOR SAFETY VERSION)
Made in: C++
Creator: program-creator-489
Creation date: May 29 2026

This is very dangerous for the non-safety version! It will destroy this computer by overwriting MBR
The Creator is NOT responsible for any damages.

" Remember the non safety version corrupts the MBR which makes the computer in a unusable state until windows is reinstalled. "